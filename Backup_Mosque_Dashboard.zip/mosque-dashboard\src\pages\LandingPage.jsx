import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  CalendarDays, 
  Users, 
  Wallet, 
  Box, 
  BarChart3, 
  ArrowRight,
  Moon
} from 'lucide-react';

const LandingPage = () => {
  const navigate = useNavigate();

  const features = [
    {
      title: 'Dashboard Interaktif',
      description: 'Ringkasan informasi terkini, saldo kas, total jemaah, dan kalender program kerja dalam widget card dinamis.',
      icon: <LayoutDashboard size={28} className="feature-icon-color" />,
      delay: '0.1s'
    },
    {
      title: 'Program Kerja',
      description: 'Manajemen kegiatan dari perencanaan hingga evaluasi. Lengkap dengan estimasi anggaran dan pencatatan absensi.',
      icon: <CalendarDays size={28} className="feature-icon-color" />,
      delay: '0.2s'
    },
    {
      title: 'Database Jemaah',
      description: 'Pengelolaan data jemaah dengan kategori khusus untuk memudahkan distribusi bantuan dan zakat secara tepat sasaran.',
      icon: <Users size={28} className="feature-icon-color" />,
      delay: '0.3s'
    },
    {
      title: 'Arus Kas Transparan',
      description: 'Pencatatan pemasukan dan pengeluaran harian, terintegrasi dengan upload bukti transaksi dan program kerja.',
      icon: <Wallet size={28} className="feature-icon-color" />,
      delay: '0.4s'
    },
    {
      title: 'Inventaris Masjid',
      description: 'Pencatatan aset masjid beserta tanggal perolehan, lokasi penyimpanan, dan kondisi barang terkini.',
      icon: <Box size={28} className="feature-icon-color" />,
      delay: '0.5s'
    },
    {
      title: 'Analisis & Laporan',
      description: 'Grafik perbandingan anggaran vs realisasi, tren infaq bulanan, serta kemudahan export laporan keuangan.',
      icon: <BarChart3 size={28} className="feature-icon-color" />,
      delay: '0.6s'
    }
  ];

  return (
    <div className="landing-container">
      {/* Navbar */}
      <nav className="landing-nav">
        <div className="landing-brand">
          <div className="brand-icon-landing">
            <Moon size={24} color="#fff" />
          </div>
          <span className="brand-text">Al-Falah</span>
        </div>
        <button className="btn-secondary" onClick={() => navigate('/dashboard')}>
          Masuk <ArrowRight size={16} />
        </button>
      </nav>

      {/* Hero Section */}
      <main className="hero-section">
        <div className="hero-content">
          <div className="hero-badge">Sistem Informasi Takmir Masjid 🚀</div>
          <h1 className="hero-title">
            Manajemen Masjid yang <span className="text-gradient">Modern</span> & Transparan
          </h1>
          <p className="hero-subtitle">
            Sentralisasi data masjid, kolaborasi pengurus, dan pelaporan keuangan real-time 
            dalam satu dashboard interaktif yang elegan.
          </p>
          <div className="hero-cta-group">
            <button className="btn-primary-large" onClick={() => navigate('/dashboard')}>
              Mulai Gunakan <ArrowRight size={20} />
            </button>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="hero-decoration">
          <div className="glow-sphere sphere-1"></div>
          <div className="glow-sphere sphere-2"></div>
        </div>
      </main>

      {/* Features Section */}
      <section className="features-section">
        <div className="features-header">
          <h2 className="section-title">Fitur Utama</h2>
          <p className="section-subtitle">Semua yang Anda butuhkan untuk operasional masjid yang profesional.</p>
        </div>
        
        <div className="features-grid">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="glass-card feature-card"
              style={{ animationDelay: feature.delay }}
            >
              <div className="feature-icon-wrapper">
                {feature.icon}
              </div>
              <h3 className="feature-title">{feature.title}</h3>
              <p className="feature-desc">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="landing-footer">
        <div className="footer-content">
          <div className="landing-brand footer-brand">
            <Moon size={20} color="#10b981" />
            <span style={{ fontWeight: 600, color: '#fff' }}>Masjid Al-Falah</span>
          </div>
          <p className="footer-text">© 2026 Dashboard Takmir Masjid Al-Falah. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
