CREATE TABLE `notification` (
	`id` varchar(36) NOT NULL,
	`type` varchar(50) NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`is_read` boolean NOT NULL DEFAULT false,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notification_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `jemaah` ADD `email` varchar(255);--> statement-breakpoint
ALTER TABLE `programs` ADD `report_doc_url` text;--> statement-breakpoint
ALTER TABLE `programs` ADD `documentation_urls` json;