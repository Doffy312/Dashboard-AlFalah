import { migrate } from "drizzle-orm/mysql2/migrator";
import { db } from "../config/db.js";

async function main() {
  console.log("🔄 Running migrations...");

  await migrate(db, { migrationsFolder: "./drizzle" });

  console.log("✅ Migrations completed successfully.");
  process.exit(0);
}

main().catch((err) => {
  console.error("❌ Migration failed:", err);
  process.exit(1);
});
