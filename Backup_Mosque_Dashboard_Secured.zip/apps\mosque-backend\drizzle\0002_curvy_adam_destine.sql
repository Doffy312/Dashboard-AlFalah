ALTER TABLE `jemaah` MODIFY COLUMN `category` varchar(50) NOT NULL DEFAULT 'Umum';--> statement-breakpoint
ALTER TABLE `programs` MODIFY COLUMN `status` varchar(50) NOT NULL DEFAULT 'Direncanakan';--> statement-breakpoint
ALTER TABLE `transactions` MODIFY COLUMN `type` varchar(50) NOT NULL;--> statement-breakpoint
CREATE INDEX `name_idx` ON `jemaah` (`name`);--> statement-breakpoint
CREATE INDEX `category_idx` ON `jemaah` (`category`);--> statement-breakpoint
CREATE INDEX `status_idx` ON `programs` (`status`);--> statement-breakpoint
CREATE INDEX `date_idx` ON `programs` (`date`);--> statement-breakpoint
CREATE INDEX `date_idx` ON `transactions` (`date`);--> statement-breakpoint
CREATE INDEX `type_idx` ON `transactions` (`type`);--> statement-breakpoint
CREATE INDEX `category_idx` ON `transactions` (`category`);