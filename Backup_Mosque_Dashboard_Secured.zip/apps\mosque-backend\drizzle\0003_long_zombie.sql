CREATE TABLE `jadwal_petugas` (
	`id` varchar(36) NOT NULL,
	`date` date NOT NULL,
	`role` varchar(50) NOT NULL,
	`person_name` varchar(255) NOT NULL,
	`contact` varchar(100),
	`topic` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `jadwal_petugas_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `qurban_participants` (
	`id` varchar(36) NOT NULL,
	`year` int NOT NULL,
	`animal_type` varchar(50) NOT NULL,
	`participant_name` varchar(255) NOT NULL,
	`status` varchar(50) NOT NULL DEFAULT 'Lunas',
	`notes` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `qurban_participants_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ziswaf_transactions` (
	`id` varchar(36) NOT NULL,
	`date` date NOT NULL,
	`type` varchar(50) NOT NULL,
	`donor_name` varchar(255) NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`description` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ziswaf_transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `jadwal_date_idx` ON `jadwal_petugas` (`date`);--> statement-breakpoint
CREATE INDEX `jadwal_role_idx` ON `jadwal_petugas` (`role`);--> statement-breakpoint
CREATE INDEX `qurban_year_idx` ON `qurban_participants` (`year`);--> statement-breakpoint
CREATE INDEX `ziswaf_date_idx` ON `ziswaf_transactions` (`date`);--> statement-breakpoint
CREATE INDEX `ziswaf_type_idx` ON `ziswaf_transactions` (`type`);